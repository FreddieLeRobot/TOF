package com.example.tof_ble_graph

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlin.random.Random.Default.nextFloat

private const val CHART_LABEL = "DATA_CHART"
private const val ENABLE_BLUETOOTH_REQUEST_CODE = 1

class MainActivity : AppCompatActivity() {

    // Bluetooth low energy variables
    private val bluetoothAdapter: BluetoothAdapter by lazy {
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothManager.adapter
    }


    // Declare floating action buttons for animations
    lateinit var bleOptionsBtn: FloatingActionButton
    lateinit var bleConnectBtn: FloatingActionButton
    lateinit var bleDisconnectBtn: FloatingActionButton

    // Declare buttons for chart
    lateinit var pauseBtn: Button
    lateinit var resetBtn: Button

    // Declare line Chart
    lateinit var lineChart: LineChart

    //Animations for the bluetooth connect buttons
    private val rotateOpen: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.rotate_open_anim) }
    private val rotateClosed: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.rotate_closed_anim) }
    private val fromBottom: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.from_bottom) }
    private val toBottom: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.to_bottom) }

    // boolean to determine if menu is expanded or not
    private var bleClicked = false

    // Mutable list for live entry of data to chart
    private val lineData = mutableListOf<Entry>()
    private var _lineDataSet = LineDataSet(lineData, CHART_LABEL)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //init FABs
        bleOptionsBtn = findViewById(R.id.bleOptions_btn)
        bleConnectBtn = findViewById(R.id.bleConnect_btn)
        bleDisconnectBtn = findViewById(R.id.bleDisconnect_btn)

        // Listeners for floating action buttons
        bleOptionsBtn.setOnClickListener{
            onBleOptionsClicked()
        }
        bleConnectBtn.setOnClickListener{
            Toast.makeText(this, "Connecting to BLE Device...", Toast.LENGTH_SHORT).show()
        }
        bleDisconnectBtn.setOnClickListener{
            Toast.makeText(this, "Disconnecting BLE Device...", Toast.LENGTH_SHORT).show()
        }

        // init Btns
        pauseBtn = findViewById(R.id.button_stop)
        resetBtn = findViewById(R.id.reset_graph)

        //Listeners for btns
        pauseBtn.setOnClickListener{
            //Todo: Actually do something with the pause btn
            lineChartAddData()
            //Toast.makeText(this, "Nothing Yet.", Toast.LENGTH_SHORT).show()
        }
        resetBtn.setOnClickListener{
            // Todo: change this listener to clear data from chart once live data is implemented
            resetLineChartData()
        }

        // Init chart
        lineChart = findViewById(R.id.lineChart)
        setLineChartStyle(lineChart)
    }

    override fun onResume() {
        super.onResume()
        if (!bluetoothAdapter.isEnabled){
            promptEnableBluetooth()
        }
    }

    private fun onBleOptionsClicked() {
        setVisibility(bleClicked)
        setAnimation(bleClicked)
        setClickable(bleClicked)
        bleClicked = !bleClicked
    }

    private fun onBleConnectClicked(){
        // TODO: Implement BLE Connect Clicked function
    }

    private fun setClickable(clicked: Boolean) {
        if (clicked){
            bleConnectBtn.isClickable = false
            bleDisconnectBtn.isClickable = false
        }
        else{
            bleConnectBtn.isClickable = true
            bleDisconnectBtn.isClickable = true
        }
    }

    private fun setVisibility(clicked: Boolean) {
        if(!clicked){
            bleConnectBtn.visibility = View.VISIBLE
            bleDisconnectBtn.visibility = View.VISIBLE
        }
        else{
            bleConnectBtn.visibility = View.INVISIBLE
            bleDisconnectBtn.visibility = View.INVISIBLE
        }
    }

    private fun setAnimation(clicked: Boolean) {
        if(!clicked){
            bleConnectBtn.startAnimation(fromBottom)
            bleDisconnectBtn.startAnimation(fromBottom)
            bleOptionsBtn.startAnimation(rotateOpen)
        }
        else{
            bleConnectBtn.startAnimation(toBottom)
            bleDisconnectBtn.startAnimation(toBottom)
            bleOptionsBtn.startAnimation(rotateClosed)
        }
    }

    /* Functions for lineChart
        Adding and resetting, themes etc.
     */

    private fun setLineChartStyle(lineChart: LineChart) = lineChart.apply{
        axisRight.isEnabled = false

        // Y Axis not changed for now
        // X Axis
        xAxis.apply {
            axisMinimum = 0f
            isGranularityEnabled = true
            setDrawGridLines(false)
            position = XAxis.XAxisPosition.BOTTOM
        }

        setTouchEnabled(true)
        isDragEnabled = true

        description = null
        legend.isEnabled = false

        //Do not want to highlight, only pan/scroll/zoom
        isHighlightPerTapEnabled = false
        isHighlightPerDragEnabled = false
    }

    private fun resetLineChartData() {

        lineData.clear()
        lineChart.data = null
        lineChart.invalidate()

    }


    private fun lineChartAddData() {

        // Todo: Remove random function and bring in data from BLE

        val fl =  nextFloat()+13f
        var index = 0f
        if (!lineData.isNullOrEmpty()){
            index = lineData.last().x + 1f
        }

        lineData.add(Entry(index,fl))

        _lineDataSet = LineDataSet(lineData, CHART_LABEL)
        lineChart.data = LineData(_lineDataSet)
        lineChart.invalidate()

    }

    // BLE Functions
    private fun promptEnableBluetooth() {
        if (!bluetoothAdapter.isEnabled) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBtIntent, ENABLE_BLUETOOTH_REQUEST_CODE)
        }
    }

}